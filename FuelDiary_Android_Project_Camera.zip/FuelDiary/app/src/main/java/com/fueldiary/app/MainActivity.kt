package com.fueldiary.app

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val MILE_TO_KM = 1.609344

data class FuelEntry(
    val date: String, val miles: Double, val full: Boolean,
    val liters: Double, val cost: Double, val photoPath: String
) {
    val km get() = miles * MILE_TO_KM
    val consumption get() = if (liters > 0 && km > 0) liters / km * 100.0 else 0.0
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FuelDiaryApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FuelDiaryApp() {
    val context = LocalContext.current
    val entries = remember { mutableStateListOf<FuelEntry>().apply { addAll(loadEntries(context)) } }
    var milesText by remember { mutableStateOf("") }
    var litersText by remember { mutableStateOf("") }
    var costText by remember { mutableStateOf("") }
    var full by remember { mutableStateOf(true) }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var photoPath by remember { mutableStateOf("") }
    var ocrStatus by remember { mutableStateOf("Dodaj zdjęcie licznika — aplikacja spróbuje odczytać mile.") }
    var showForm by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }

    var pendingPhotoFile by remember { mutableStateOf<File?>(null) }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        val file = pendingPhotoFile
        if (success && file != null) {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            photoUri = uri
            photoPath = file.absolutePath
            try {
                val input = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(input)
                    .addOnSuccessListener { result ->
                        val found = Regex("""\d{1,7}(?:[.,]\d{1,2})?""")
                            .findAll(result.text).mapNotNull { it.value.replace(',', '.').toDoubleOrNull() }
                            .firstOrNull()
                        if (found != null) {
                            milesText = found.toString()
                            ocrStatus = "Odczytano: $found mi. Sprawdź i popraw, jeśli trzeba."
                        } else ocrStatus = "Nie rozpoznano liczby. Wpisz mile ręcznie."
                    }
                    .addOnFailureListener { ocrStatus = "Nie udało się odczytać zdjęcia. Wpisz mile ręcznie." }
            } catch (_: Exception) { ocrStatus = "Nie udało się otworzyć zdjęcia." }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF287A55))) {
        Scaffold(topBar = { TopAppBar(title = { Text("Fuel Diary", fontWeight = FontWeight.Bold) }) }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card(shape = RoundedCornerShape(20.dp)) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("Twój dziennik tankowań", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            Text("Zdjęcie licznika • mile i kilometry • koszty", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { showForm = !showForm }, modifier = Modifier.fillMaxWidth()) {
                                Text(if (showForm) "Zamknij formularz" else "＋ Nowe tankowanie")
                            }
                        }
                    }
                }
                if (showForm) {
                    item {
                        Card {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Nowy wpis", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Button(onClick = {
                                    try {
                                        val file = File(context.filesDir, "fuel_${System.currentTimeMillis()}.jpg")
                                        pendingPhotoFile = file
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                        cameraLauncher.launch(uri)
                                    } catch (_: Exception) {
                                        ocrStatus = "Nie udało się uruchomić aparatu."
                                    }
                                }, modifier = Modifier.fillMaxWidth()) { Text("📷 Zrób zdjęcie licznika") }
                                Text(ocrStatus, style = MaterialTheme.typography.bodySmall)
                                OutlinedTextField(milesText, { milesText = it }, label = { Text("Odczyt licznika (mile)") }, modifier = Modifier.fillMaxWidth())
                                if (milesText.toDoubleOrNull() != null) {
                                    Text("≈ ${"%.1f".format(milesText.toDouble() * MILE_TO_KM)} km", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = full, onCheckedChange = { full = it })
                                    Text("Zatankowano do pełna")
                                }
                                OutlinedTextField(litersText, { litersText = it }, label = { Text("Ilość paliwa (litry) — opcjonalnie") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(costText, { costText = it }, label = { Text("Kwota (zł)") }, modifier = Modifier.fillMaxWidth())
                                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
                                Button(onClick = {
                                    val miles = milesText.replace(',', '.').toDoubleOrNull()
                                    val liters = litersText.replace(',', '.').toDoubleOrNull() ?: 0.0
                                    val cost = costText.replace(',', '.').toDoubleOrNull() ?: 0.0
                                    if (miles == null || miles < 0) { error = "Dodaj lub popraw odczyt mil ze zdjęcia."; return@Button }
                                    val date = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())
                                    entries.add(0, FuelEntry(date, miles, full, liters, cost, photoPath))
                                    saveEntries(context, entries)
                                    milesText = ""; litersText = ""; costText = ""; photoPath = ""; photoUri = null; pendingPhotoFile = null
                                    ocrStatus = "Dodaj zdjęcie licznika — aplikacja spróbuje odczytać mile."
                                    error = ""; showForm = false
                                }, modifier = Modifier.fillMaxWidth()) { Text("Zapisz w dzienniku") }
                            }
                        }
                    }
                }
                item { Text("Historia tankowań", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
                if (entries.isEmpty()) item { Text("Nie ma jeszcze wpisów. Dodaj pierwsze tankowanie.") }
                items(entries) { entry ->
                    Card(shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            val bitmap = remember(entry.photoPath) {
                                if (entry.photoPath.isNotBlank()) BitmapFactory.decodeFile(entry.photoPath) else null
                            }
                            if (bitmap != null) Image(bitmap.asImageBitmap(), null, Modifier.size(104.dp), contentScale = ContentScale.Crop)
                            else Box(Modifier.size(104.dp).background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("Brak zdjęcia") }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(entry.date, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(if (entry.full) "Pełny bak" else "Niepełne tankowanie", fontWeight = FontWeight.Bold)
                                Text("${"%.1f".format(entry.miles)} mi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Text("${"%.1f".format(entry.km)} km", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                if (entry.liters > 0) Text("${"%.1f".format(entry.liters)} L • spalanie ${"%.1f".format(entry.consumption)} L/100 km", style = MaterialTheme.typography.bodySmall)
                                Text("Koszt: ${"%.2f".format(entry.cost)} zł", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun saveEntries(context: Context, entries: List<FuelEntry>) {
    val array = JSONArray()
    entries.forEach { e ->
        array.put(JSONObject().put("date", e.date).put("miles", e.miles).put("full", e.full)
            .put("liters", e.liters).put("cost", e.cost).put("photo", e.photoPath))
    }
    context.getSharedPreferences("fuel_diary", Context.MODE_PRIVATE).edit().putString("entries", array.toString()).apply()
}
private fun loadEntries(context: Context): List<FuelEntry> {
    return try {
        val raw = context.getSharedPreferences("fuel_diary", Context.MODE_PRIVATE).getString("entries", "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            FuelEntry(o.optString("date"), o.optDouble("miles"), o.optBoolean("full"),
                o.optDouble("liters"), o.optDouble("cost"), o.optString("photo"))
        }
    } catch (_: Exception) { emptyList() }
}

# Fuel Diary — projekt Android

## Otwieranie
1. Zainstaluj Android Studio.
2. Rozpakuj archiwum i otwórz folder `FuelDiary`.
3. Poczekaj na synchronizację Gradle.
4. Podłącz telefon z włączonym debugowaniem USB albo uruchom emulator.
5. Kliknij Run.

## Co zawiera wersja startowa
- lokalny dziennik tankowań (bez konta),
- zdjęcie licznika z galerii,
- próba odczytu tekstu ze zdjęcia przez ML Kit,
- możliwość poprawienia odczytu,
- mile i automatycznie przeliczone kilometry,
- zaznaczenie tankowania do pełna,
- ilość litrów i kwota,
- zdjęcie obok wpisu w historii.

## Ważne ograniczenia wersji startowej
- Zdjęcie licznika można zrobić bezpośrednio aparatem telefonu.
- OCR rozpoznaje tekst, ale może pomylić cyfry na wyświetlaczu. Zawsze sprawdź odczyt przed zapisaniem.
- Dokładne spalanie wymaga wpisywania litrów i tankowania metodą od pełnego do pełnego. Wpisy niepełne nie dają samodzielnie wiarygodnego spalania.
- To projekt źródłowy, nie gotowy plik APK. APK należy zbudować w Android Studio.

## Prywatność
Wpisy i skopiowane zdjęcia są przechowywane lokalnie w prywatnym katalogu aplikacji. Odinstalowanie aplikacji może usunąć te dane — warto robić kopię zapasową.
